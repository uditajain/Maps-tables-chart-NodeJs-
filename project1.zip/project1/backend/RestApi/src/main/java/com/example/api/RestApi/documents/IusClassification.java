package com.example.api.RestApi.documents;


public class IusClassification 
{
	private String _id;
	private String ref_id;
	
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getRef_id() {
		return ref_id;
	}
	public void setRef_id(String ref_id) {
		this.ref_id = ref_id;
	}	
}

