package com.example.api.RestApi.repository;

import com.example.api.RestApi.customRepository.CutsomAreaRepository;
import com.example.api.RestApi.documents.Area;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AreaRepository extends MongoRepository<Area,String>,CutsomAreaRepository
{	
	
} 
