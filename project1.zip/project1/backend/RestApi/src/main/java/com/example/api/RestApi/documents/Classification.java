package com.example.api.RestApi.documents;


import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "classification")
public class Classification
{
    private String createdAt;

    private String __v;

    private String _id;

    private String level1;

    private int type;

    private String uuid;

    private String level2;

    private String status;

    private String updatedAt;

    public String getCreatedAt ()
    {
        return createdAt;
    }

    public void setCreatedAt (String createdAt)
    {
        this.createdAt = createdAt;
    }

    public String get__v ()
    {
        return __v;
    }

    public void set__v (String __v)
    {
        this.__v = __v;
    }

    public String get_id ()
    {
        return _id;
    }

    public void set_id (String _id)
    {
        this._id = _id;
    }

    public String getLevel1 ()
    {
        return level1;
    }

    public void setLevel1 (String level1)
    {
        this.level1 = level1;
    }

    public int getType ()
    {
        return type;
    }

    public void setType (int type)
    {
        this.type = type;
    }

    public String getUuid ()
    {
        return uuid;
    }

    public void setUuid (String uuid)
    {
        this.uuid = uuid;
    }

    public String getLevel2 ()
    {
        return level2;
    }

    public void setLevel2 (String level2)
    {
        this.level2 = level2;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

    public String getUpdatedAt ()
    {
        return updatedAt;
    }

    public void setUpdatedAt (String updatedAt)
    {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [createdAt = "+createdAt+", __v = "+__v+", _id = "+_id+", level1 = "+level1+", type = "+type+", uuid = "+uuid+", level2 = "+level2+", status = "+status+", updatedAt = "+updatedAt+"]";
    }
}

