package com.example.api.RestApi.controller;
import java.util.ArrayList;
import java.util.HashMap;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Enumeration;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.LinkedHashSet;
import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.RestController;

import com.example.api.RestApi.documents.Area;
import com.example.api.RestApi.documents.Classification;
import com.example.api.RestApi.documents.CustomArea;
import com.example.api.RestApi.documents.Data;
import com.example.api.RestApi.documents.IUS;
import com.example.api.RestApi.documents.TimePeriod;
import com.example.api.RestApi.services.IusServices;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Collation;

import org.springframework.data.mongodb.core.MongoOperations;
//import com.mongodb.operation.GroupOperation;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
public class DashBoradController 
{
	@Autowired 
	IusServices iusService;		
	//HttpServletRequest hs;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	
	
	@Autowired
	MongoOperations mongooperations;
	
	@GetMapping("/getAlldata/{time_Period}")
	public List<TimePeriod> getDataByalltimeperiod() 
	{   	
		Query query =new Query();
	return mongoTemplate.findDistinct(query,"time_period",Data.class,TimePeriod.class);
	}
	
	
	@GetMapping("getAllArea")
	 public HashMap<Integer, HashMap<String, String>> getClassificationDatta(){
		Query query = new Query();
		  List<Area> sorted = new ArrayList<>();
		  sorted = mongoTemplate.find(query ,Area.class );
			query.fields().include("name");
		query.addCriteria(Criteria.where("area_code").is("IND003018"));
		 HashMap<Integer, HashMap<String, String>> myArray = new HashMap<Integer, HashMap<String, String>>();
		  for(int i=0; i<sorted.size();i++) {
			   HashMap<String, String> value = new HashMap<String, String>();
			   value.put("AreaName", sorted.get(i).getName());
			   value.put("Status",  sorted.get(i).getStatus());
			   
			   myArray.put(i , value);
	        }
		   return myArray;
	}
	@GetMapping("/getdatabyiusid")
	   public List<IUS> getiusidd() {
		{
		LookupOperation lookupOperation = LookupOperation.newLookup().
       from("data").
       localField("iu_id").
       foreignField("_id").
       as("data");
			//AggregationOperation match = Aggregation.match(Criteria.where("_id").in(getiusid()));	
		Aggregation aggregation = Aggregation.newAggregation(lookupOperation);
List<IUS> results = mongooperations.aggregate(aggregation,"ius",IUS.class).getMappedResults();
return results;
	}
	}
	
	
	
	 @GetMapping("/getDatabyAreaa")
	   public List<Area>getAllDataAreaa()
	   {
		   
		   LookupOperation lookupOperation=LookupOperation.newLookup().
					from("data").
					localField("status").
					foreignField("status").
					as("data");
		   Aggregation aggregation=Aggregation.newAggregation(lookupOperation);
			List<Area> listdata =mongooperations.aggregate(aggregation,"area",Area.class).getMappedResults();	
		      return listdata;
	   }
	
	
	
	
	@GetMapping("/getDatta")
    public List<CustomArea>getData()
	{
		List<CustomArea> arraylistius=new ArrayList<CustomArea>();	
	Query query=new Query();
		List<Area> listius1=mongoTemplate.find(query, Area.class);
		for(Area obj:listius1)
		{
			CustomArea  area=new CustomArea ();
			area.setName(obj.getName());
			area.setStatus(obj.getStatus());
			arraylistius.add(area);
		}
		return arraylistius;
	}
	
	
	
//	@GetMapping("/getDatta")
//    public List<CustomArea>getDaata()
//	{
//		List<CustomArea> arraylistius=new ArrayList<CustomArea>();	
//	Query query=new Query();
//		List<IUS> listius1=mongoTemplate.find(query, IUS.class);
//		for(IUS obj:listius1)
//		{
//			CustomArea  ius=new CustomArea ();
//			ius.setName(obj.getName());
//			ius.setStatus(obj.getUnit());
////			ius.setSubgroup(obj)
//			
//			ius.setName(obj.getName());
//			ius.setStatus(obj.getStatus());
//			arraylistius.add(ius);
//		}
//		return arraylistius;
//	}
	
	
	
	
	}