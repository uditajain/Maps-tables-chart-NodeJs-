package com.example.api.RestApi.documents;


public class Source 
{
	private String publisher;

    public String getPublisher()
    {
        return publisher;
    }

    public void setPublisher(String publisher)
    {
        this.publisher = publisher;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [publisher = "+publisher+"]";
    }
}


