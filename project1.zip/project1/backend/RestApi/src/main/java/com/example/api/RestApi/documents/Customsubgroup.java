package com.example.api.RestApi.documents;

import java.util.List;
public class Customsubgroup {
	

		private String name;

	    private String lowercase_name;

	    private String _id;


	    private String subgroup_dimension;

	    private String default_subgroup;

	    private String status;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getLowercase_name() {
			return lowercase_name;
		}

		public void setLowercase_name(String lowercase_name) {
			this.lowercase_name = lowercase_name;
		}

		public String get_id() {
			return _id;
		}

		public void set_id(String _id) {
			this._id = _id;
		}

		public String getSubgroup_dimension() {
			return subgroup_dimension;
		}

		public void setSubgroup_dimension(String subgroup_dimension) {
			this.subgroup_dimension = subgroup_dimension;
		}

		public String getDefault_subgroup() {
			return default_subgroup;
		}

		public void setDefault_subgroup(String default_subgroup) {
			this.default_subgroup = default_subgroup;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public void setSubgroup_dimension(List<SubGroup> subgroup) {
			// TODO Auto-generated method stub
			
		}























}

