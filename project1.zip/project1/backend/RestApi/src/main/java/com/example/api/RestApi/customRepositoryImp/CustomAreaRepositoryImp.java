package com.example.api.RestApi.customRepositoryImp;
import com.example.api.RestApi.customRepository.CutsomAreaRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;


public class CustomAreaRepositoryImp implements CutsomAreaRepository 
{

}

