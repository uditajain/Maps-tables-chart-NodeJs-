package com.example.api.RestApi.documents;


import java.util.List;

import org.springframework.boot.context.properties.PropertyMapper.Source;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

//import com.itm.mpi.service.string;

@Document(collection = "data")
public class Data
{
	@Id
    private String _id;
	
    private String ius_id;

    private String area_code;

    private Source source;

    private String footnote;

    private Double numerator;
     
    private String indicator;

    private String iu_id;

    private String createdAt;

    private String __v;

    private Double denomenator;

    private String value;

    private TimePeriod time_period;

    private String status;

    private String updatedAt;
    

    
	public String getIus_id() {
		return ius_id;
	}

	public void setIus_id(String ius_id) {
		this.ius_id = ius_id;
	}

	public String getArea_code() {
		return area_code;
	}

	public void setArea_code(String area_code) {
		this.area_code = area_code;
	}

	public Source getSource() {
		return source;
	}

	public void setSource(Source source) {
		this.source = source;
	}

	public String getFootnote() {
		return footnote;
	}

	public void setFootnote(String footnote) {
		this.footnote = footnote;
	}

	
	
	
	
	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public Double getNumerator() {
		return numerator;
	}

	public void setNumerator(Double numerator) {
		this.numerator = numerator;
	}

	public String getIu_id() {
		return iu_id;
	}

	public void setIu_id(String iu_id) {
		this.iu_id = iu_id;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String get__v() {
		return __v;
	}

	public void set__v(String __v) {
		this.__v = __v;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public Double getDenomenator() {
		return denomenator;
	}

	public void setDenomenator(Double denomenator) {
		this.denomenator = denomenator;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public TimePeriod getTime_period() {
		return time_period;
	}

	public void setTime_period(TimePeriod time_period) {
		this.time_period = time_period;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Object get_subgroup() {
		// TODO Auto-generated method stub
		return null;
	}


	
	
	
//	public List<Data> getData() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	
	
//	public List<SubGroup> getData() {
//		// TODO Auto-generated method stub
//		return null;
//	}

//	public void setName(String name) {
//		// TODO Auto-generated method stub
//		
//	}

	
	

//	public List<Area> getareaid() {
//		// TODO Auto-generated method stub
//		return null;
//	}    	
}	

