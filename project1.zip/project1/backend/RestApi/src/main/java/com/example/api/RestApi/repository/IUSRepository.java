package com.example.api.RestApi.repository;
import com.example.api.RestApi.customRepository.CutsomAreaRepository;
import com.example.api.RestApi.documents.Data;
import com.example.api.RestApi.documents.IUS;

import java.util.List;

import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface IUSRepository extends MongoRepository<IUS,String>,CutsomAreaRepository
{
	
	
	}

