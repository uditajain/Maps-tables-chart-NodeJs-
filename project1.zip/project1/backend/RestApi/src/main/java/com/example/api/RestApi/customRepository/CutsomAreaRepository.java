package com.example.api.RestApi.customRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CutsomAreaRepository 
{

}
