package com.example.api.RestApi.documents;


import java.io.Serializable;
import java.util.List;

public class ChartData implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String value;
	
	private String code;
	
	private Boolean is_aspirational;
	
	private String parent_code;
	
	private String name;
	
	private int length;
	
	private Source source;
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Source getSource() {
		return source;
	}

	public void setSource(Source source) {
		this.source = source;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Boolean getIs_aspirational() {
		return is_aspirational;
	}

	public void setIs_aspirational(Boolean is_aspirational) {
		this.is_aspirational = is_aspirational;
	}

	public String getParent_code() {
		return parent_code;
	}

	public void setParent_code(String parent_code) {
		this.parent_code = parent_code;
	}

	
	
}

