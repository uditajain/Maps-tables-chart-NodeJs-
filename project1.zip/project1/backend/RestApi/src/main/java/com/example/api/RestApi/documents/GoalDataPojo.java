package com.example.api.RestApi.documents;


import java.util.Comparator;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class GoalDataPojo 
{
	@JsonIgnore
	private String _id;
	private String area_code;
	
	@JsonIgnore
	private Source source;
	
	@JsonIgnore
	private TimePeriod time_period;
	
	@JsonIgnore
	private Double denomenator;
	
	@JsonIgnore
	private Double numerator;
	
	@JsonIgnore
	private String status;
	private String footnote;
	private String value;
	private String area_name;
	private String indicatorName;
	
	@JsonIgnore
	private int count;
	
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getArea_code() {
		return area_code;
	}
	public void setArea_code(String area_code) {
		this.area_code = area_code;
	}
	public Source getSource() {
		return source;
	}
	public void setSource(Source source) {
		this.source = source;
	}
	public TimePeriod getTime_period() {
		return time_period;
	}
	public void setTime_period(TimePeriod time_period) {
		this.time_period = time_period;
	}
	public Double getDenomenator() {
		return denomenator;
	}
	public void setDenomenator(Double denomenator) {
		this.denomenator = denomenator;
	}
	public Double getNumerator() {
		return numerator;
	}
	public void setNumerator(Double numerator) {
		this.numerator = numerator;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFootnote() {
		return footnote;
	}
	public void setFootnote(String footnote) {
		this.footnote = footnote;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getArea_name() {
		return area_name;
	}
	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}
	public String getIndicatorName() {
		return indicatorName;
	}
	public void setIndicatorName(String indicatorName) {
		this.indicatorName = indicatorName;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}	
	
	public static Comparator<GoalDataPojo> areaNameComparator = new Comparator<GoalDataPojo>() 
	{         
	    @Override         
	    public int compare(GoalDataPojo jc1, GoalDataPojo jc2) 
	    {             
	      return (int) (jc1.getArea_name().compareTo(jc2.getArea_name()));    
	    }     
	};
	
	public static Comparator<GoalDataPojo> dataValueComparator = new Comparator<GoalDataPojo>() {         
	    @Override         
	    public int compare(GoalDataPojo jc1, GoalDataPojo jc2) {             
	      return ( Double.parseDouble(jc2.getValue()) < Double.parseDouble(jc1.getValue()) ? -1 :                     
	              (Double.parseDouble(jc2.getValue()) == Double.parseDouble(jc1.getValue()) ? 0 : 1));           
	    }     
	  };   
}

