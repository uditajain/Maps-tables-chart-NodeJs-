package com.example.api.RestApi.documents;


public class DefaultVisualization 
{
	private String chart_type;

    private String[] subgroup_name;

    private String time_period;

    public String getChart_type ()
    {
        return chart_type;
    }

    public void setChart_type (String chart_type)
    {
        this.chart_type = chart_type;
    }

    public String[] getSubgroup_name ()
    {
        return subgroup_name;
    }

    public void setSubgroup_name (String[] subgroup_name)
    {
        this.subgroup_name = subgroup_name;
    }

    public String getTime_period ()
    {
        return time_period;
    }

    public void setTime_period (String time_period)
    {
        this.time_period = time_period;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [chart_type = "+chart_type+", subgroup_name = "+subgroup_name+", time_period = "+time_period+"]";
    }
}

