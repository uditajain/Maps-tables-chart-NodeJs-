package com.example.api.RestApi.repository;
import java.util.List;

import com.example.api.RestApi.customRepository.CutsomAreaRepository;
import com.example.api.RestApi.documents.Data;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DataRepository extends MongoRepository<Data,String>,CutsomAreaRepository
{
	List<Data> getDataByStatus(int status);
}

