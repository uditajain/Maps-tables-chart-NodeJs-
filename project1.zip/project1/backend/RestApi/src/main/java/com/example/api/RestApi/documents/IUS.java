package com.example.api.RestApi.documents;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ius")
public class IUS {

	//private DefaultVisualization default_viz;

    private String createdAt;

    private String unit;

	


   // private List<SubGroup> subgroup;

    private String __v;

    private String name;

    private String _id;

    private String high_is_good;

    private String status;

    private String updatedAt;
    
    @DBRef(lazy = true)
	//@JsonIgnore
    private List<Data> data;
    
    
//	public DefaultVisualization getDefault_viz() {
//		return default_viz;
//	}
//
//	public void setDefault_viz(DefaultVisualization default_viz) {
//		this.default_viz = default_viz;
//	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

//	public List<SubGroup> getSubgroup() {
//		return subgroup;
//	}
//
//	public void setSubgroup(List<SubGroup> subgroup) {
//		this.subgroup = subgroup;
//	}
//


	public String get__v() {
		return __v;
	}

	public void set__v(String __v) {
		this.__v = __v;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getHigh_is_good() {
		return high_is_good;
	}

	public void setHigh_is_good(String high_is_good) {
		this.high_is_good = high_is_good;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<Data> getData() {
		return data;
	}

	public void setData(List<Data> data) {
		this.data = data;
	}

	
	
//	public List<Data> getData() {
//		// TODO Auto-generated method stub
//		return null;
//	}

//	public List<SubGroup> getyear() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public List<Area> getareaid() {
//		// TODO Auto-generated method stub
//		return null;
//	}

   
}


