package com.example.api.RestApi.services;

import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;

import com.example.api.RestApi.documents.Data;
import com.example.api.RestApi.documents.TimePeriod;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

@Service
public class IusServices 
{

	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	Aggregation aggregation;
	
	
	

	/*get data by time period*/	
	public List<TimePeriod>  getAllTimePeriods() {
		//DBObject dbObject = new BasicDBObject();
		Query query =new Query();

		return mongoTemplate.findDistinct(query,"time_period",Data.class,TimePeriod.class);
		
	}
	
}
