package com.example.api.RestApi.documents;


import java.util.List;

public class TableData 
{
	private String area_name;
	
	private String area_code;
	
	public List<ChartData> chartdata;
	

	public String getArea_name() {
		return area_name;
	}

	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}

	public List<ChartData> getChartdata() {
		return chartdata;
	}

	public void setChartdata(List<ChartData> chartdata) {
		this.chartdata = chartdata;
	}

	public String getArea_code() {
		return area_code;
	}

	public void setArea_code(String area_code) {
		this.area_code = area_code;
	}
	
	
	
}
