package com.example.api.RestApi.documents;


import java.io.Serializable;

public class dataSelection implements Serializable {

	
	
	
	private String _areaId;
	
	private String _timeperiod;
	
	private String _dimension;
	
	private String _subgroup;
	
	private String indicator;

	private Boolean isLastTP;
	  
	
	
	
	public String get_areaId() {
		return _areaId;
	}

	public void set_areaId(String _areaId) {
		this._areaId = _areaId;
	}

	public String get_timeperiod() {
		return _timeperiod;
	}

	public void set_timeperiod(String _timeperiod) {
		this._timeperiod = _timeperiod;
	}

	public String get_dimension() {
		return _dimension;
	}

	public void set_dimension(String _dimension) {
		this._dimension = _dimension;
	}

	public String get_subgroup() {
		return _subgroup;
	}

	public void set_subgroup(String _subgroup) {
		this._subgroup = _subgroup;
	}

	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public Boolean getIsLastTP() {
		return isLastTP;
	}

	public void setIsLastTP(Boolean isLastTP) {
		this.isLastTP = isLastTP;
	}

	
	
	
	
	
	

	@Override
	public String toString() {
		return "dataSelection [_areaId=" + _areaId + ", _timeperiod=" + _timeperiod + ", _dimension=" + _dimension
				+ ", _subgroup=" + _subgroup + ", indicator=" + indicator + ", isLastTP=" + isLastTP + "]";
	}


	
	
	
}

