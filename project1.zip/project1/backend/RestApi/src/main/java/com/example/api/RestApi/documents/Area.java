package com.example.api.RestApi.documents;


import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "area")
public class Area 
{
	@Id
    private String _id;	
	
    private String area_group;

    private String createdAt;

    private String level;

    private String parent_id;

    private String area_code;

    private String __v;

    private String name;

    private String status;

    private String updatedAt;
    
    private Boolean is_aspirational;

	@DBRef(lazy = true)
	//@JsonIgnore
    private List<Data> data;

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getArea_group() {
		return area_group;
	}

	public void setArea_group(String area_group) {
		this.area_group = area_group;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getParent_id() {
		return parent_id;
	}

	public void setParent_id(String parent_id) {
		this.parent_id = parent_id;
	}

	public String getArea_code() {
		return area_code;
	}

	public void setArea_code(String area_code) {
		this.area_code = area_code;
	}

	public String get__v() {
		return __v;
	}

	public void set__v(String __v) {
		this.__v = __v;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}	

 
	public List<Data> getData() {
		return data;
}

public void setData(List<Data> data) {
	this.data = data;
	}

	public Boolean getIs_aspirational() {
		return is_aspirational;
	}

	public void setIs_aspirational(Boolean is_aspirational) {
		this.is_aspirational = is_aspirational;
	}

	

	
	
}
