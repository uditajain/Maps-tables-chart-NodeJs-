package com.example.api.RestApi.documents;
import java.io.Serializable;


public class CustomArea  implements Serializable {
private String name;
private String Status;


private String unit;
private String Subgroup;





public String getSubgroup() {
	return Subgroup;
}
public void setSubgroup(String subgroup) {
	Subgroup = subgroup;
}
//@Override
//public String toString() {
//	return "CustomArea [name=" + name + ", Status=" + Status + "]";
//}
public String getName() {
	return name;
}
@Override
public String toString() {
	return "CustomArea [name=" + name + ", Status=" + Status + ", unit=" + unit + ", Subgroup=" + Subgroup + "]";
}
public void setName(String name) {
	this.name = name;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}

	
	
	
}
