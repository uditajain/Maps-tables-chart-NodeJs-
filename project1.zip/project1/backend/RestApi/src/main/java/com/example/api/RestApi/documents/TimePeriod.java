package com.example.api.RestApi.documents;

public class TimePeriod 
{
	private String start_time_period;

	public String getStart_time_period() {
		return start_time_period;
	}

	public void setStart_time_period(String start_time_period) {
		this.start_time_period = start_time_period;
	}

	
}